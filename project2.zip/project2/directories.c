#include "mysync.h"
#include <dirent.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>

//method to add all initial files into surface level directories
void addFiles(char *string)
{
	DIR *dir;
	struct dirent *entry;
	
	//if directory couldnt be opened then this is not a directory
	dir = opendir(string);
	if(dir == NULL)
	{
		if(vflag)
		{
			printf("directory %s does not exist\n",string);
		}
		perror("directory does not exist\n");
		exit(EXIT_FAILURE);
	}

	struct DIRECTORY new_dir;
	
	new_dir.name = (char *)malloc(strlen(string) + 1); // +1 for the null-terminator

	if (new_dir.name != NULL) 
	{
    		strcpy(new_dir.name, string);
	} else 
	{
   	 	perror("Memory allocation error for new_dir.name");
		exit(EXIT_FAILURE);
	}
	
	//initialising variables
	new_dir.files = NULL;
	int fileCount = 0;
	new_dir.filesToBeAdded = NULL;
	new_dir.filesToBeAddedCount = 0;
	new_dir.dirs = NULL;
	new_dir.dirCount = 0;
	new_dir.dirsToBeAdded = NULL;
	new_dir.dirsToBeAddedCount = 0;

	//going through all contents of directory
	while ((entry = readdir(dir)) != NULL) 
	{
		//if file starts with '.' then this is a hidden file. Only use if -a flag was used.
		if(entry->d_name[0] != '.' || aflag)
		{
			if(iflag && matchesPattern(entry->d_name,iflagPatterns, iflagPatternsCount))
			{
				continue;
			}

			if(oflag && !matchesPattern(entry->d_name,oflagPatterns, oflagPatternsCount))
			{
				continue;
			}

			struct  REG_FILE  file;
			
			struct stat fileStat;
			
			file.location = (char *)malloc(strlen(string) + strlen(entry->d_name) + 2); // +2 for the null-terminator and '/' character
			sprintf(file.location,"%s/%s",string,entry->d_name);

    			if(stat(file.location, &fileStat) == 0) 
			{
       			 	// The modification time is stored
        			 file.mod =  fileStat.st_mtime;
    			} else 
			{
        			perror("Error getting file information\n");
				exit(EXIT_FAILURE);
    			}
			
			if(S_ISDIR(fileStat.st_mode))
			{
				//only if recursively checking
				if(rflag)
				{

					//add this directory to directories array within the struct
					new_dir.dirCount++;
					char *innerDirName = file.location;
					new_dir.dirs = (struct DIRECTORY *)realloc(new_dir.dirs, new_dir.dirCount * sizeof(struct DIRECTORY));
				
					if(new_dir.dirs == NULL)
					{
						perror("Error: dirs array could not be reallocated");
						exit(EXIT_FAILURE);
					}
				
					struct DIRECTORY innerDirectory = copyDirectoryContents(innerDirName);
					
					innerDirectory.name = (char *)malloc(strlen(entry->d_name) + 1); // +1 for the null-terminator
					strcpy(innerDirectory.name, entry->d_name);

					new_dir.dirs[new_dir.dirCount - 1] = innerDirectory;

					//did not end up being a file so free this location
					free(file.location);
					file.location = NULL;
					
					//since this is not a file continue to next file
					continue;
				}else
				{
					free(file.location);
					file.location = NULL;

					//since this is not a file continue to next file
					continue;
				}
			}
			
			file.name = (char *)malloc(strlen(entry->d_name) + 1); // +1 for the null-terminator
			strcpy(file.name, entry->d_name);

			fileCount++;
			
			//add the file to the files array within struct
			new_dir.files = (struct REG_FILE *)realloc(new_dir.files, fileCount * sizeof(struct REG_FILE));
			
			if(new_dir.files == NULL)
			{
				perror("Error: files array could not be reallocated");	
				exit(EXIT_FAILURE);
			}

			 new_dir.files[fileCount-1] = file;
			
		}
    	}
	
	new_dir.fileCount =  fileCount;
	
	//add this directory to the surface directories array
	directories = (struct DIRECTORY *)realloc(directories, (dirIndex + 1) * sizeof(struct DIRECTORY));

	if (directories == NULL) 
	{
        	perror("Error reallocating memory for the directories");
        	exit(EXIT_FAILURE);
    	}

	directories[dirIndex] = new_dir;
	
	if(vflag)
	{
		printf("%s\n",directories[dirIndex].name);
		for(int i = 0; i < directories[dirIndex].fileCount; i++)
		{
			printf("\t%s\t%s\n",directories[dirIndex].files[i].name,ctime(&directories[dirIndex].files[i].mod));
		}
	}

	closedir(dir);

	dirIndex++;
}

//very similar method to one above but this one recursively searches for more directories and returns the directory
struct DIRECTORY copyDirectoryContents(char *innerDirName)
{
	DIR *dir;
	struct dirent *entry;
	
	//if directory couldnt be opened then this is not a directory
	dir = opendir(innerDirName);
	if(dir == NULL)
	{
		if(vflag)
		{
			printf("directory %s does not exist\n",innerDirName);
		}
		perror("directory does not exist\n");
		exit(EXIT_FAILURE);
	}

	struct DIRECTORY new_dir;
	
	new_dir.name = (char *)malloc(strlen(innerDirName) + 1); // +1 for the null-terminator

	if (new_dir.name != NULL) 
	{
    		strcpy(new_dir.name, innerDirName);
	} else 
	{
   	 	perror("Memory allocation error for new_dir.name");
		exit(EXIT_FAILURE);
	}
	
	new_dir.files = NULL;
	int fileCount = 0;
	new_dir.filesToBeAdded = NULL;
	new_dir.filesToBeAddedCount = 0;
	new_dir.dirs = NULL;
	new_dir.dirCount = 0;
	new_dir.dirsToBeAdded = NULL;
	new_dir.dirsToBeAddedCount = 0;

	//going through all contents of directory
	while ((entry = readdir(dir)) != NULL) 
	{
		//if file starts with '.' then this is a hidden file. Only use if -a flag was used.
		if(entry->d_name[0] != '.' || aflag)
		{
			if(iflag && matchesPattern(entry->d_name,iflagPatterns, iflagPatternsCount))
			{
				continue;
			}

			if(oflag && !matchesPattern(entry->d_name,oflagPatterns, oflagPatternsCount))
			{
				continue;
			}

			struct  REG_FILE  file;
			
			struct stat fileStat;
			
			file.location = (char *)malloc(strlen(innerDirName) + strlen(entry->d_name) + 2); // +2 for the null-terminator and '/' character
			sprintf(file.location,"%s/%s",innerDirName,entry->d_name);

    			if(stat(file.location, &fileStat) == 0) 
			{
       			 	// The modification time is stored
        			 file.mod =  fileStat.st_mtime;
    			} else 
			{
        			perror("Error getting file information\n");
				exit(EXIT_FAILURE);
    			}
			
			if(S_ISDIR(fileStat.st_mode))
			{
				new_dir.dirCount++;
				char *innerDirName = file.location;
				new_dir.dirs = (struct DIRECTORY *)realloc(new_dir.dirs, new_dir.dirCount * sizeof(struct DIRECTORY));
				
				if(new_dir.dirs == NULL)
				{
					perror("Error: dirs array could not be reallocated");
					exit(EXIT_FAILURE);
				}
				
				struct DIRECTORY innerDirectory = copyDirectoryContents(innerDirName);
					
				innerDirectory.name = (char *)malloc(strlen(entry->d_name) + 1); // +1 for the null-terminator
				strcpy(innerDirectory.name, entry->d_name);

				new_dir.dirs[new_dir.dirCount - 1] = innerDirectory;

				free(file.location);
				file.location = NULL;
				continue;
			}
			
			file.name = (char *)malloc(strlen(entry->d_name) + 1); // +1 for the null-terminator
			strcpy(file.name, entry->d_name);

			fileCount++;
			new_dir.files = (struct REG_FILE *)realloc(new_dir.files, fileCount * sizeof(struct REG_FILE));
			
			if(new_dir.files == NULL)
			{
				perror("Error: files array could not be reallocated");	
				exit(EXIT_FAILURE);
			}

			 new_dir.files[fileCount-1] = file;
			
		}
    	}
	
	new_dir.fileCount =  fileCount;

	closedir(dir);

	return new_dir;
}
