#include "mysync.h"
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <utime.h>

//check if file currently exists in a given list
int NonExistingFile(struct REG_FILE *files,int fileCount, struct REG_FILE file)
{
	for(int i = 0; i < fileCount; i++)
	{
		//check if file is in already
		if(strcmp(files[i].name, file.name) == 0)
		{
			if(vflag)
			{
				printf("%s is same name as %s in %s\n",file.name,files[i].name,files[i].location);
			}
			
			//compare mod times
			if(file.mod > files[i].mod)
			{
				if(vflag)
				{
					printf("\t%s : %s is newer than %s in %s : ",file.name, ctime(&file.mod),files[i].name,files[i].location);
					printf("%s\n",ctime(&files[i].mod));
				}

				//return the index and +2 to indicate success and to get the index
				return (2+i);
			}else
			{
				if(vflag)
				{
					printf("\t%s : %s is not newer than %s in %s : ",file.name, ctime(&file.mod),files[i].name,files[i].location);
					printf("%s\n",ctime(&files[i].mod));
				}
				//failiure (older version in files array)
				return 0;
			}
		}
		
	}
	
	if(vflag)
	{
		printf("%s is not in directory\n",file.name);
	}
	//success: file not in array
	return 1;
}

void copy_file(char *destination, char *source)        
{
//  ATTEMPT TO OPEN source FOR READ-ONLY ACCESS
    int fd0    = open(source, O_RDONLY);
//  ENSURE THE FILE COULD BE OPENED
    if(fd0 == -1) 
    {
        perror("File could not be opened with read only access");
	exit(EXIT_FAILURE);
    }

	

//  ATTEMPT TO OPEN destination FOR WRITE-ONLY ACCESS
    int fd1    = open(destination, O_WRONLY);
//  ENSURE THE FILE COULD BE OPENED
    if(fd1 == -1) {
        close(fd0);
        perror("File could not be opened with write only access");
	exit(EXIT_FAILURE);
    }

//  DEFINE A CHARACTER ARRAY TO HOLD THE FILE'S CONTENTS
    char *buffer = (char *)malloc(strlen(source) + 1);
    size_t got;

//  PERFORM MULTIPLE READs OF FILE UNTIL END-OF-FILE REACHED  
    while((got = read(fd0, buffer, sizeof buffer)) > 0) {  
        if(write(fd1, buffer, got) != got) {  
            close(fd0); close(fd1);
            perror("File could not be written");
	    exit(EXIT_FAILURE);
        }
    }

    free(buffer);
	buffer = NULL;
    close(fd0); close(fd1);

	//change permissions if -p was used
	if(pflag)
	{
		struct stat srcStat;
		if (stat(source, &srcStat) == -1) 
		{
			perror("stat for source");
			close(fd0);
			exit(EXIT_FAILURE);
		}

		struct stat dstStat;	
		if (stat(destination, &dstStat) == -1) 
		{
			perror("stat for destination");
			close(fd1);
			exit(EXIT_FAILURE);
		}

		struct utimbuf newTimes;

		newTimes.actime = dstStat.st_atime; //access Time
		newTimes.modtime = srcStat.st_mtime; // Modification time
		
		//changing mod time
		if (utime(destination, &newTimes) == -1) 
		{
				perror("utime");
				exit(EXIT_FAILURE);
		}

		
		if (chmod(destination, srcStat.st_mode) == -1) 
		{
        	perror("Error setting destination file permissions\n");
        	exit(EXIT_FAILURE);
    	}else if(vflag)
		{
			printf("File permissions copied\n");
		}
	}
	
}
