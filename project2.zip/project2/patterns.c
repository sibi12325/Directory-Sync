#include "mysync.h"
#include <stdbool.h>
#include <regex.h>

//method to see if the filename matches the pattern specified
bool matchesPattern(char *fileName,regex_t *patterns, int patternCount)
{
	for(int i = 0; i < patternCount; i++)
	{
		regex_t regex = patterns[i];
		if (regexec(&regex, fileName, 0, NULL, 0) == 0) 
		{
         	  	// The filename matches the regular expression
           	 	return true;
       		}
	}
	return false;

}
