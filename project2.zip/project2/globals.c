#include  "mysync.h"
#include <regex.h>

//initialise global variables
bool      vflag = false;
bool      aflag = false;
bool      nflag = false;
bool      rflag = false;
bool      pflag = false;
bool      iflag = false;
bool      oflag = false;
struct DIRECTORY *directories = NULL;
int	  dirIndex = 0;
regex_t *iflagPatterns = NULL;
int iflagPatternsCount = 0;
regex_t *oflagPatterns = NULL;
int oflagPatternsCount = 0;
