#include  <stdio.h>
#include  <stdlib.h>
#include  <stdbool.h>
#include <time.h>
#include <regex.h>

//DECLARE GLOBAL STRUCTS	
struct REG_FILE
{
	char *name;
	char* location;
	time_t mod;
};

struct DIRECTORY
{
	char *name;
	int fileCount;
	struct REG_FILE *files;
	int filesToBeAddedCount;
	struct REG_FILE *filesToBeAdded;
	struct DIRECTORY *dirs;
	int dirCount;
	struct DIRECTORY *dirsToBeAdded;
	int dirsToBeAddedCount;
	char *location;
	
};

// DECLARE GLOBAL FUNCTIONS
extern void         addFiles(char *); // parameter is not named
extern int	    NonExistingFile(struct REG_FILE *,int, struct REG_FILE);
extern void 	    copy_file(char *, char *);
extern struct DIRECTORY copyDirectoryContents(char *);
extern void 	    prepareSync(struct DIRECTORY *,struct DIRECTORY *);
extern void 	    sync(struct DIRECTORY *,char *);
extern char 	*glob2regex(char *);
extern bool matchesPattern(char *,regex_t *, int);

// DECLARE GLOBAL VARIABLES
extern	bool       vflag;
extern  bool	   aflag;
extern  bool	   nflag;
extern  bool	   rflag;
extern  bool	   pflag;
extern  bool	   iflag;
extern  bool	   oflag;
extern  struct DIRECTORY *directories;
extern  int	   dirIndex;
extern  regex_t *iflagPatterns;
extern  int iflagPatternsCount;
extern  regex_t *oflagPatterns;
extern  int oflagPatternsCount;
