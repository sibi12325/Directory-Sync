#include <stdlib.h>
#include <stdio.h>
#include "mysync.h"
#include <getopt.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdbool.h>
#include <regex.h>

//  CITS2002 Project 2 2023
//  Student1:   23615908   SIBI MOOTHEDAN
//  Student2:   STUDENT-NUMBER2   NAME-2

//option list containing all of the possible options that can be used
#define	OPTLIST		"vanrpi:o:"

int main(int argc, char *argv[])
{
        //  ENSURE THAT WE HAVE THE CORRECT NUMBER OF COMMAND-LINE ARGUMENTS
        if(argc <= 1) 
        {
                printf("Usage : %s [options]  directory1  directory2  [directory3  ...]",argv[0]);
                exit(EXIT_FAILURE);
        }
	
	//variable containing number of options found
	int optcount = 0;

	//iterating through all used options and updating respective option flag
	int opt;
	while((opt = getopt(argc, argv, OPTLIST)) != -1)	
	{
		optcount++;
		
		if(opt == 'v') 
		{
			vflag = true;
        	}

		if(opt == 'a') 
		{
			aflag = true;
        	}
		
		if(opt == 'n') 
		{
			vflag = true;
			nflag = true;
        	}

		if(opt == 'r') 
		{
			rflag = true;
        	}
		
		if(opt == 'p') 
		{
			pflag = true;
        	}

		if(opt == 'i') 
		{
			iflag = true;
			char *pattern = glob2regex(optarg);
			regex_t regex;
   			int ret = regcomp(&regex, pattern, REG_EXTENDED);
			if (ret != 0) 
			{
       				perror("Could not compile Regular Expression");
        			exit(EXIT_FAILURE);
    			}
			iflagPatternsCount++;
			iflagPatterns = (regex_t *)realloc(iflagPatterns,iflagPatternsCount*sizeof(regex_t));
			iflagPatterns[iflagPatternsCount - 1] = regex;

			//increment this as next argv value is the string associated with command
			optcount++;
        }
	
		if(opt == 'o') 
		{
			oflag = true;
			char *pattern = glob2regex(optarg);
			regex_t regex;
   			int ret = regcomp(&regex, pattern, REG_EXTENDED);
			if (ret != 0) 
			{
       				perror("Could not compile Regular Expression");
        			exit(EXIT_FAILURE);
    			}

			oflagPatternsCount++;
			oflagPatterns = (regex_t *)realloc(oflagPatterns,oflagPatternsCount*sizeof(regex_t));
			oflagPatterns[oflagPatternsCount - 1] = regex;
			optcount++;
        }
	}

	//first directiory found 1 after all used options.
	int directoryStartPosition = optcount + 1;
	for(int i = directoryStartPosition; i < argc; i++)
	{
		addFiles(argv[i]);
	}
	
	//prepare all directories for syncing with each other
	for(int j = 0; j < dirIndex; j++)
	{
		for(int k = 0; k < dirIndex; k++)
		{
			if(j != k)
			{
				prepareSync(&directories[j],&directories[k]);
			}
        }
	}
	
	//sync all directories
	for(int k = 0; k < dirIndex; k++)
	{
		char *destination = directories[k].name;
		sync(&directories[k],destination);
	}
	
	for(int i = 0; i < iflagPatternsCount; i++)
	{
		regfree(&iflagPatterns[i]);
	}
	free(iflagPatterns);
	
	for(int i = 0; i < oflagPatternsCount; i++)
	{
		regfree(&oflagPatterns[i]);
	}
	free(oflagPatterns);
	
}

//method to add all files and directories to be copied into its correct locations
void prepareSync(struct DIRECTORY *dir1,struct DIRECTORY *dir2)
{

	if(vflag)
	{
		printf("Comparing files in %s with %s\n",dir1->name,dir2->name);
	}			

	//adding all files to be copied
	for(int i = 0; i < dir1->fileCount; i++)
	{
		
		printf("\t");
		
		//if file is not part of directory (or is newer) then add to list (where list is list containing files to be added)
		if(NonExistingFile(dir2->files,dir2->fileCount, dir1->files[i]) > 0)
		{
			if(NonExistingFile(dir2->filesToBeAdded,dir2->filesToBeAddedCount, dir1->files[i]) > 1)
			{
				int index = NonExistingFile(dir2->filesToBeAdded,dir2->filesToBeAddedCount, dir1->files[i]) - 2;
				dir2->filesToBeAdded[index] = dir1->files[i];
			}else
			{
				dir2->filesToBeAddedCount = dir2->filesToBeAddedCount + 1;
				dir2->filesToBeAdded = (struct REG_FILE *)realloc(dir2->filesToBeAdded, dir2->filesToBeAddedCount * sizeof(struct REG_FILE));
				if(dir2->filesToBeAdded == NULL)
				{
					perror("Error: dir2->filesToBeAdded array could not be reallocated");	
					exit(EXIT_FAILURE);
				}
				dir2->filesToBeAdded[dir2->filesToBeAddedCount-1] = dir1->files[i];
			}
		}

	}		

	//if -r is used do same thing as above but with directories
	if(rflag)
	{
		if(vflag)
		{
			printf("Comparing directories in %s with %s\n",dir1->name,dir2->name);
		}

	//adding directories to be added to correct locations
		for(int i = 0; i < dir1->dirCount; i++)
			{
			if(dir1->dirs[i].fileCount != 0 || dir1->dirs[i].dirCount != 0)
			{
				printf("\t");

				dir2->dirsToBeAddedCount = dir2->dirsToBeAddedCount + 1;
				dir2->dirsToBeAdded = (struct DIRECTORY *)realloc(dir2->dirsToBeAdded, dir2->dirsToBeAddedCount * sizeof(struct DIRECTORY));
				if(dir2->dirsToBeAdded == NULL)
				{
					perror("Error: *dir2->dirsToBeAdded array could not be reallocated");	
					exit(EXIT_FAILURE);
				}
				
				char *destination = dir1->name;
				char *full_path = (char *)malloc(strlen(dir1->dirs[i].name) + strlen(destination) + 2); //2 for '\0' and '/' characters		
				sprintf(full_path,"%s/%s",destination,dir1->dirs[i].name);

				printf("directory path : %s\n",full_path);
				struct DIRECTORY subDir = copyDirectoryContents(full_path);
				subDir.name = (char *)realloc(subDir.name,strlen(dir1->dirs[i].name) + 1);
				if(subDir.name == NULL)
				{
					perror("Error: subDir.name could not be reallocated");	
					exit(EXIT_FAILURE);
				}

				subDir.name = (char *)realloc(subDir.name,strlen(dir1->dirs[i].name) + 1);
				if(subDir.name == NULL)
				{
					perror("Error: subDir.name could not be reallocated");	
					exit(EXIT_FAILURE);
				}
				
				strcpy(subDir.name,dir1->dirs[i].name);

				subDir.location = (char *)malloc(strlen(full_path) + 1);
				strcpy(subDir.location,full_path);

				printf("SubDir name is : %s \t dirCount = %i\n",subDir.name,subDir.dirCount);
				

				dir2->dirsToBeAdded[dir2->dirsToBeAddedCount-1] = subDir;
				
				printf("SubDir name is : %s \t dirCount = %i\n",dir2->dirsToBeAdded[dir2->dirsToBeAddedCount-1].name,dir2->dirsToBeAdded[dir2->dirsToBeAddedCount-1].dirCount);
				
				free(full_path);
				full_path = NULL;

				printf("%s\n",dir1->dirs[i].name);
			}
			
		

		}
	}
}

//method to actually copy over files and sync
void sync(struct DIRECTORY *dir1,char *path)
{

	//only do so if nflag is not passed
	if(!nflag && rflag)
	{
		if(vflag)
		{
			printf("-------------------Starting Directory Copy--------------------\n");
		}

		for(int i = 0; i < dir1->dirsToBeAddedCount; i++)
		{	
			if(dir1->dirsToBeAdded[i].dirCount != 0|| dir1->dirsToBeAdded[i].fileCount != 0)
			{
				char *full_path = (char *)malloc(strlen(dir1->dirsToBeAdded[i].name) + strlen(path) + 2); //2 for '\0' and '/' characters
				sprintf(full_path,"%s/%s",path,dir1->dirsToBeAdded[i].name);
				
				bool exists = false;
				
				//attempt to make a directory. if you fail, the directory exists
				if (mkdir(full_path, 0777) == -1) 
				{
					if(vflag)
					{	
						exists = true;	
						printf("Subirectory already exists\n");
					}
				}
				
				printf("------I GOT HERE A-----------\n");

				//adds all files of nested directories
				for(int p = 0; p < dir1->dirsToBeAdded[i].fileCount; p++)
				{	

					char *file_path = (char *)malloc(strlen(dir1->dirsToBeAdded[i].files[p].name) + strlen(full_path) + 2); //2 for '\0' and '/' characters
					sprintf(file_path,"%s/%s",full_path,dir1->dirsToBeAdded[i].files[p].name);

					if(exists)
					{					
						struct DIRECTORY destinationDir = copyDirectoryContents(full_path);		

						if(NonExistingFile(destinationDir.files,dir1->dirsToBeAdded[i].fileCount, dir1->dirsToBeAdded[i].files[p]) > 0)
						{
							if(NonExistingFile(destinationDir.files,dir1->dirsToBeAdded[i].fileCount, dir1->dirsToBeAdded[i].files[p]) >= 2)
							{
								copy_file(file_path, dir1->dirsToBeAdded[i].files[p].location);
							}else
							{
								printf("-------File path is : %s\n",file_path);
								FILE* file = fopen(file_path, "w");			
								copy_file(file_path, dir1->dirsToBeAdded[i].files[p].location);
								fclose(file);
							}
						}
					}else
					{	
						FILE* file = fopen(file_path, "w");			
						copy_file(file_path, dir1->dirsToBeAdded[i].files[p].location);
						fclose(file);
					}
				
					if(vflag)
					{
						printf("%s copied to %s\n",dir1->dirsToBeAdded[i].files[p].name,file_path);
					}
				}	
				
				for(int p = 0; p < dir1->dirsToBeAdded[i].dirCount; p++)
				{
					char *originalPath = (char *)malloc(strlen(dir1->dirsToBeAdded[i].location) + strlen(dir1->dirsToBeAdded[i].dirs[p].name) + 2);
					sprintf(originalPath,"%s/%s",dir1->dirsToBeAdded[i].location,dir1->dirsToBeAdded[i].dirs[p].name);
					struct DIRECTORY nestedDirOriginalLocation = copyDirectoryContents(originalPath);
					char *complete_path = (char *)malloc(strlen(dir1->dirsToBeAdded[i].dirs[p].name) + strlen(full_path) + 2); //2 for '\0' and '/' characters
					sprintf(complete_path,"%s/%s",full_path,dir1->dirsToBeAdded[i].dirs[p].name);
				
					//attempt to make a directory. if you fail, the directory exists
					if (mkdir(complete_path, 0777) == -1) 
					{
						if(vflag)
						{		
							printf("Subirectory already exists\n");
						}
					}
					
					
					struct DIRECTORY nestedDirNewLocation = copyDirectoryContents(complete_path);
					
					prepareSync(&nestedDirOriginalLocation,&nestedDirNewLocation);

					char *oldName = dir1->dirsToBeAdded[i].dirs[p].name;
					dir1->dirsToBeAdded[i].dirs[p] = nestedDirNewLocation;	
					dir1->dirsToBeAdded[i].dirs[p].name = oldName;
					
					printf("------STARTING SYNC------");
					sync(&dir1->dirsToBeAdded[i].dirs[p],complete_path);
				}
				
				if(vflag)
				{
					printf("Directory %s copied to %s\n",dir1->dirsToBeAdded[i].name,path);
				}

				free(full_path);
				full_path = NULL;

			}
		}
	}
		
	if(vflag)
	{	
		printf("\nFiles to be moved to %s : \n",dir1->name);
		for(int i = 0; i < dir1->filesToBeAddedCount; i++)
		{
		
			printf("\t %s \t Location : %s\n",dir1->filesToBeAdded[i].name,dir1->filesToBeAdded[i].location);
		}
	}

	//copying over the files
	if(!nflag)
	{
		if(vflag)
		{
			printf("-------------------Starting File Copy--------------------\n");
		}

		char *destination = dir1->name;
		for(int i = 0; i < dir1->filesToBeAddedCount; i++)
		{	
			char *currentPath = path;
			char *full_path = (char *)malloc(strlen(dir1->filesToBeAdded[i].name) + strlen(currentPath) + 2); //2 for '\0' and '/' characters
			sprintf(full_path,"%s/%s",currentPath,dir1->filesToBeAdded[i].name);
			printf("%s\n",full_path);
			FILE* file = fopen(full_path, "w");				
			copy_file(full_path, dir1->filesToBeAdded[i].location);
			fclose(file);
			if(vflag)
			{
				printf("%s copied to %s\n",dir1->filesToBeAdded[i].name,destination);
			}
			free(full_path);
			full_path = NULL;
		}
	}
	
	if(vflag && rflag)
	{	
		printf("\nDirectories to be moved to %s : \n",dir1->name);
		for(int i = 0; i < dir1->dirsToBeAddedCount; i++)
		{
		
			printf("\t %s\n",dir1->dirsToBeAdded[i].name);
		}
	}
}

